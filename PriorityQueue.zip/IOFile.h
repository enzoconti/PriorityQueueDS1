#ifndef IOFile_h
#define IOFile_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Queue.h"


int getInstruction();
PERSON readInput();
void printPerson(PERSON);

#endif
